package soup.neumorphism.sample.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class CardSampleActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sample_card)
    }
}
