---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

Version used:
Devices/Android versions reproduced on:

I would appreciate if you could attach:
- Sample codes to trigger the issue.
- A screenrecord or screenshots showing the issue.
